#define functions at the top

def say_hello():
    print("Hello")
    print("I hope you are having a great day!")
    print()
    
def say_goodbye():
    print("Goodbye")
    print("See you next time!")
    print()
    
 #let's call our functions

say_hello()

say_goodbye()
    
