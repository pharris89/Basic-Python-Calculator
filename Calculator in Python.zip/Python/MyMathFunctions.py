def add_numbers(first, second):
    sum = first + second
    return sum
def subtract_numbers(first, second):
    difference = first - second
    return difference
def multiply_numbers(first, second):
    total = first * second
    return total
def divide_numbers(first, second):
    quotient = first / second
    return quotient